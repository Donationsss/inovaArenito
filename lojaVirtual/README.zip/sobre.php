<?php
session_start();
$isLogged = isset($_SESSION['usuario_id']);
$isAdmin  = !empty($_SESSION['is_admin']);
$username = $_SESSION['usuario_nome'] ?? 'Usuário';
?>


<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre - TechStore</title>
    <link rel="stylesheet" href="./css/styles.css">
    <link rel="stylesheet" href="./css/sobre.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <!-- Header -->
    <header class="header">
        <nav class="navbar container">
            <div style="display: flex; align-items: center; justify-content:space-between">
            </div>
            <div class="logo">
                <i class="fas fa-store"></i>
                <span>TechStore</span>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php" class="nav-link">Home</a></li>
                <li><a href="produtos.php" class="nav-link">Produtos</a></li>
                <li><a href="sobre.php" class="nav-link active">Sobre</a></li>
            </ul>
            <div class="nav-actions" data-aos="fade-left" data-aos-delay="100">
                <div class="nav-actions">
                    <button class="theme-toggle" id="themeToggle">
                        <i class="fas fa-moon"></i>
                    </button>

                    <button class="cart-btn">
                        <i class="fas fa-shopping-cart"></i>
                        <span class="cart-count">0</span>
                    </button>

                    <?php if (!$isLogged): ?>
                        <a href="login.php" class="btn btn-outline nav-login">
                            <i class="fas fa-sign-in-alt"></i> Entrar
                        </a>
                    <?php else: ?>
                        <div class="nav-user dropdown">
                            <button class="dropdown-toggle" aria-haspopup="true" aria-expanded="false">
                                <img
                                    src="https://ui-avatars.com/api/?name=<?= urlencode($username) ?>&background=2563eb&color=fff&size=64"
                                    alt="Avatar" class="nav-avatar">
                                <span class="nav-username"><?= htmlspecialchars($username) ?></span>
                                <i class="fas fa-chevron-down dropdown-caret"></i>
                            </button>
                            <div class="dropdown-menu">
                                <?php if ($isAdmin): ?>
                                    <a href="dashboard.php" class="dropdown-item">
                                        <i class="fas fa-chart-line"></i> Voltar ao Dashboard
                                    </a>
                                <?php endif; ?>
                                <a href="logout.php" class="dropdown-item">
                                    <i class="fas fa-sign-out-alt"></i> Logout
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
        </nav>
    </header>

    <!-- Hero Sobre -->
    <section class="sobre-hero">
        <div class="container">
            <div class="sobre-hero-content" data-aos="fade-up">
                <h1>Sobre a <span class="gradient-text">TechStore</span></h1>
                <p>Somos apaixonados por tecnologia e dedicados a trazer os melhores produtos para você</p>
            </div>
        </div>
    </section>

    <!-- Nossa História -->
    <section class="nossa-historia">
        <div class="container">
            <div class="historia-content">
                <div class="historia-text" data-aos="fade-right">
                    <h2 class="section-title">Nossa <span class="gradient-text">História</span></h2>
                    <p>Fundada em 2015, a TechStore nasceu do sonho de democratizar o acesso à tecnologia de qualidade no Brasil. Começamos como uma pequena loja online e, ao longo dos anos, conquistamos a confiança de milhares de clientes em todo o país.</p>
                    <p>Hoje, somos referência em produtos de tecnologia, oferecendo desde componentes de hardware até os smartphones mais modernos do mercado. Nossa missão é simples: proporcionar a melhor experiência de compra online, com produtos de qualidade e preços justos.</p>
                    <div class="historia-stats">
                        <div class="stat-item">
                            <h3>10+</h3>
                            <p>Anos de Experiência</p>
                        </div>
                        <div class="stat-item">
                            <h3>50k+</h3>
                            <p>Clientes Satisfeitos</p>
                        </div>
                        <div class="stat-item">
                            <h3>500+</h3>
                            <p>Produtos Disponíveis</p>
                        </div>
                    </div>
                </div>
                <div class="historia-image" data-aos="fade-left">
                    <img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600" alt="Nossa História">
                </div>
            </div>
        </div>
    </section>

    <!-- Valores -->
    <section class="valores">
        <div class="container">
            <div class="section-header" data-aos="fade-up">
                <h2 class="section-title">Nossos <span class="gradient-text">Valores</span></h2>
                <p class="section-subtitle">O que nos move todos os dias</p>
            </div>
            <div class="valores-grid">
                <div class="valor-card" data-aos="fade-up">
                    <div class="valor-icon">
                        <i class="fas fa-heart"></i>
                    </div>
                    <h3>Paixão</h3>
                    <p>Somos apaixonados por tecnologia e trabalhamos com dedicação para oferecer o melhor aos nossos clientes.</p>
                </div>
                <div class="valor-card" data-aos="fade-up" data-aos-delay="100">
                    <div class="valor-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h3>Confiança</h3>
                    <p>Construímos relacionamentos baseados em transparência, honestidade e compromisso com a qualidade.</p>
                </div>
                <div class="valor-card" data-aos="fade-up" data-aos-delay="200">
                    <div class="valor-icon">
                        <i class="fas fa-rocket"></i>
                    </div>
                    <h3>Inovação</h3>
                    <p>Estamos sempre em busca das últimas novidades e tendências do mercado tecnológico.</p>
                </div>
                <div class="valor-card" data-aos="fade-up" data-aos-delay="300">
                    <div class="valor-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3>Atendimento</h3>
                    <p>Nosso time está pronto para oferecer suporte completo antes, durante e depois da sua compra.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Diferenciais -->
    <section class="diferenciais">
        <div class="container">
            <div class="diferenciais-content">
                <div class="diferenciais-image" data-aos="fade-right">
                    <img src="https://images.unsplash.com/photo-1556761175-b413da4baf72?w=600" alt="Diferenciais">
                </div>
                <div class="diferenciais-text" data-aos="fade-left">
                    <h2 class="section-title">Por que escolher a <span class="gradient-text">TechStore?</span></h2>
                    <div class="diferencial-item">
                        <i class="fas fa-check-circle"></i>
                        <div>
                            <h4>Produtos Originais</h4>
                            <p>Trabalhamos apenas com produtos originais e de marcas reconhecidas no mercado.</p>
                        </div>
                    </div>
                    <div class="diferencial-item">
                        <i class="fas fa-check-circle"></i>
                        <div>
                            <h4>Melhores Preços</h4>
                            <p>Preços competitivos e condições especiais de pagamento para você.</p>
                        </div>
                    </div>
                    <div class="diferencial-item">
                        <i class="fas fa-check-circle"></i>
                        <div>
                            <h4>Entrega Rápida</h4>
                            <p>Logística eficiente para garantir que seu pedido chegue no prazo.</p>
                        </div>
                    </div>
                    <div class="diferencial-item">
                        <i class="fas fa-check-circle"></i>
                        <div>
                            <h4>Garantia Estendida</h4>
                            <p>Todos os produtos com garantia do fabricante e opção de garantia estendida.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Time -->
    <section class="time">
        <div class="container">
            <div class="section-header" data-aos="fade-up">
                <h2 class="section-title">Nosso <span class="gradient-text">Time</span></h2>
                <p class="section-subtitle">Conheça quem faz a TechStore acontecer</p>
            </div>
            <div class="time-grid">
                <div class="membro-card" data-aos="fade-up">
                    <div class="membro-image">
                        <img src="https://ui-avatars.com/api/?name=Carlos+Silva&background=2563eb&color=fff&size=200" alt="Carlos Silva">
                    </div>
                    <h3>Carlos Silva</h3>
                    <p class="cargo">CEO & Fundador</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>
                <div class="membro-card" data-aos="fade-up" data-aos-delay="100">
                    <div class="membro-image">
                        <img src="https://ui-avatars.com/api/?name=Ana+Santos&background=8b5cf6&color=fff&size=200" alt="Ana Santos">
                    </div>
                    <h3>Ana Santos</h3>
                    <p class="cargo">Diretora de Operações</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>
                <div class="membro-card" data-aos="fade-up" data-aos-delay="200">
                    <div class="membro-image">
                        <img src="https://ui-avatars.com/api/?name=Pedro+Costa&background=10b981&color=fff&size=200" alt="Pedro Costa">
                    </div>
                    <h3>Pedro Costa</h3>
                    <p class="cargo">Gerente de Tecnologia</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>
                <div class="membro-card" data-aos="fade-up" data-aos-delay="300">
                    <div class="membro-image">
                        <img src="https://ui-avatars.com/api/?name=Julia+Lima&background=f59e0b&color=fff&size=200" alt="Julia Lima">
                    </div>
                    <h3>Julia Lima</h3>
                    <p class="cargo">Head de Marketing</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA -->
    <section class="cta-section">
        <div class="container">
            <div class="cta-content" data-aos="fade-up">
                <h2>Pronto para começar?</h2>
                <p>Explore nosso catálogo completo e encontre os melhores produtos de tecnologia</p>
                <a href="produtos.html" class="btn btn-primary btn-large">
                    Ver Produtos
                    <i class="fas fa-arrow-right"></i>
                </a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-col">
                    <div class="logo">
                        <i class="fas fa-store"></i>
                        <span>TechStore</span>
                    </div>
                    <p>Sua loja de tecnologia de confiança</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                    </div>
                </div>
                <div class="footer-col">
                    <h3>Links Rápidos</h3>
                    <ul>
                        <li><a href="index.html">Home</a></li>
                        <li><a href="produtos.html">Produtos</a></li>
                        <li><a href="sobre.html">Sobre</a></li>
                        <li><a href="dashboard.html">Dashboard</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h3>Suporte</h3>
                    <ul>
                        <li><a href="#">FAQ</a></li>
                        <li><a href="#">Política de Privacidade</a></li>
                        <li><a href="#">Termos de Uso</a></li>
                        <li><a href="#">Contato</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h3>Newsletter</h3>
                    <p>Receba nossas ofertas exclusivas</p>
                    <form class="newsletter-form">
                        <input type="email" placeholder="Seu e-mail">
                        <button type="submit"><i class="fas fa-paper-plane"></i></button>
                    </form>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 TechStore. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>

    <!-- Cart Modal -->
    <div class="cart-modal" id="cartModal">
        <div class="cart-content">
            <div class="cart-header">
                <h2><i class="fas fa-shopping-cart"></i> Carrinho</h2>
                <button class="close-cart">&times;</button>
            </div>
            <div class="cart-items" id="cartItems">
                <p class="empty-cart">Seu carrinho está vazio</p>
            </div>
            <div class="cart-footer">
                <div class="cart-total">
                    <span>Total:</span>
                    <span id="cartTotal">R$ 0,00</span>
                </div>
                <button class="btn btn-primary" onclick="finalizarCompra()">
                    <i class="fas fa-check"></i> Finalizar Compra
                </button>
            </div>
        </div>
    </div>

    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="js/theme-switcher.js"></script>
    <script src="js/main.js"></script>
</body>

</html>