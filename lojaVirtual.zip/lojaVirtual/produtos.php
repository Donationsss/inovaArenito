<?php
session_start();
$isLogged = isset($_SESSION['usuario_id']);
$isAdmin  = !empty($_SESSION['is_admin']);
$username = $_SESSION['usuario_nome'] ?? 'Usuário';
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produtos - TechStore</title>
    <link rel="stylesheet" href="./css/styles.css">
    <link rel="stylesheet" href="./css/produtos.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <!-- Header -->
    <header class="header">
        <nav class="navbar container">
            <div style="display: flex; align-items: center; justify-content:space-between">
            </div>
            <div class="logo">
                <i class="fas fa-store"></i>
                <span>TechStore</span>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php" class="nav-link">Home</a></li>
                <li><a href="produtos.php" class="nav-link active">Produtos</a></li>
                <li><a href="sobre.php" class="nav-link">Sobre</a></li>
            </ul>
            <div class="nav-actions" data-aos="fade-left" data-aos-delay="100">
                <div class="nav-actions">
                    <button class="theme-toggle" id="themeToggle">
                        <i class="fas fa-moon"></i>
                    </button>

                    <button class="cart-btn">
                        <i class="fas fa-shopping-cart"></i>
                        <span class="cart-count">0</span>
                    </button>

                    <?php if (!$isLogged): ?>
                        <a href="login.php" class="btn btn-outline nav-login">
                            <i class="fas fa-sign-in-alt"></i> Entrar
                        </a>
                    <?php else: ?>
                        <div class="nav-user dropdown">
                            <button class="dropdown-toggle" aria-haspopup="true" aria-expanded="false">
                                <img
                                    src="https://ui-avatars.com/api/?name=<?= urlencode($username) ?>&background=2563eb&color=fff&size=64"
                                    alt="Avatar" class="nav-avatar">
                                <span class="nav-username"><?= htmlspecialchars($username) ?></span>
                                <i class="fas fa-chevron-down dropdown-caret"></i>
                            </button>
                            <div class="dropdown-menu">
                                <?php if ($isAdmin): ?>
                                    <a href="dashboard.php" class="dropdown-item">
                                        <i class="fas fa-chart-line"></i> Voltar ao Dashboard
                                    </a>
                                <?php endif; ?>
                                <a href="logout.php" class="dropdown-item">
                                    <i class="fas fa-sign-out-alt"></i> Logout
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
        </nav>
    </header>

    <!-- Produtos Page -->
    <div class="produtos-page">
        <div class="container-fluid">
            <div class="produtos-layout">
                <!-- Sidebar -->
                <aside class="produtos-sidebar">
                    <div class="sidebar-section">
                        <h3 class="sidebar-title">
                            <i class="fas fa-list"></i>
                            Categorias
                        </h3>
                        <ul class="category-list">
                            <li>
                                <a href="#" class="category-item active" data-category="all">
                                    <span>Todos os Produtos</span>
                                    <span class="count">370</span>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="category-item" data-category="hardware">
                                    <span>Hardware</span>
                                    <span class="count">85</span>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="category-item" data-category="perifericos">
                                    <span>Periféricos</span>
                                    <span class="count">120</span>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="category-item" data-category="computadores">
                                    <span>Computadores</span>
                                    <span class="count">45</span>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="category-item" data-category="notebooks">
                                    <span>Notebooks</span>
                                    <span class="count">65</span>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="category-item" data-category="smartphones">
                                    <span>Smartphones</span>
                                    <span class="count">55</span>
                                </a>
                            </li>
                        </ul>
                    </div>

                    <div class="sidebar-section">
                        <h3 class="sidebar-title">
                            <i class="fas fa-filter"></i>
                            Preço
                        </h3>
                        <div class="price-filter">
                            <div class="price-inputs">
                                <input type="number" placeholder="Mín" id="minPrice">
                                <span>-</span>
                                <input type="number" placeholder="Máx" id="maxPrice">
                            </div>
                            <button class="btn-filter">Aplicar</button>
                        </div>
                    </div>

                    <div class="sidebar-section">
                        <h3 class="sidebar-title">
                            <i class="fas fa-star"></i>
                            Avaliação
                        </h3>
                        <ul class="rating-filter">
                            <li>
                                <label>
                                    <input type="checkbox" value="5">
                                    <span class="stars">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                    </span>
                                    <span class="count">(45)</span>
                                </label>
                            </li>
                            <li>
                                <label>
                                    <input type="checkbox" value="4">
                                    <span class="stars">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="far fa-star"></i>
                                    </span>
                                    <span class="count">(128)</span>
                                </label>
                            </li>
                            <li>
                                <label>
                                    <input type="checkbox" value="3">
                                    <span class="stars">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="far fa-star"></i>
                                        <i class="far fa-star"></i>
                                    </span>
                                    <span class="count">(97)</span>
                                </label>
                            </li>
                        </ul>
                    </div>

                    <div class="sidebar-section">
                        <h3 class="sidebar-title">
                            <i class="fas fa-tag"></i>
                            Marcas
                        </h3>
                        <ul class="brand-filter">
                            <li><label><input type="checkbox" value="gigabyte"> Gigabyte</label></li>
                            <li><label><input type="checkbox" value="msi"> MSI</label></li>
                            <li><label><input type="checkbox" value="asus"> ASUS</label></li>
                            <li><label><input type="checkbox" value="amd"> AMD</label></li>
                            <li><label><input type="checkbox" value="intel"> Intel</label></li>
                            <li><label><input type="checkbox" value="kingston"> Kingston</label></li>
                        </ul>
                    </div>

                    <button class="btn-clear-filters">
                        <i class="fas fa-times"></i>
                        Limpar Filtros
                    </button>
                </aside>

                <!-- Main Content -->
                <main class="produtos-main">
                    <!-- Toolbar -->
                    <div class="produtos-toolbar">
                        <div class="toolbar-left">
                            <button class="btn-toggle-sidebar">
                                <i class="fas fa-bars"></i>
                            </button>
                            <span class="produtos-count"><strong>370</strong> produtos encontrados</span>
                        </div>
                        <div class="toolbar-right">
                            <select class="sort-select">
                                <option value="">Ordenar por</option>
                                <option value="popular">Mais Populares</option>
                                <option value="recent">Mais Recentes</option>
                                <option value="price-low">Menor Preço</option>
                                <option value="price-high">Maior Preço</option>
                                <option value="rating">Melhor Avaliação</option>
                            </select>
                            <div class="view-toggle">
                                <button class="view-btn active" data-view="grid">
                                    <i class="fas fa-th"></i>
                                </button>
                                <button class="view-btn" data-view="list">
                                    <i class="fas fa-list"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Produtos Grid -->
                    <div class="produtos-grid" id="produtosGrid">
                        <!-- Produto 1 -->
                        <div class="produto-card" data-category="notebooks">
                            <div class="produto-badge">Frete Grátis</div>
                            <div class="produto-image">
                                <img src="https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400" alt="Notebook">
                                <div class="produto-overlay">
                                    <button class="btn-quick-view">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="produto-info">
                                <h3 class="produto-title">Placa de Vídeo RX 7600 GAMING OC 8G AMD Radeon Gigabyte</h3>
                                <p class="produto-description">8GB, GDDR6, 128bit</p>
                                <div class="produto-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star-half-alt"></i>
                                    <span>(723)</span>
                                </div>
                                <div class="produto-footer">
                                    <div class="price-group">
                                        <span class="produto-price-old">R$ 2.352,99</span>
                                        <span class="produto-price">R$ 1.739,99</span>
                                        <span class="discount-badge">-12%</span>
                                    </div>
                                    <button class="btn-add-cart" onclick="addToCart('Placa de Vídeo RX 7600', 1739.99, 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400')">
                                        <i class="fas fa-cart-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Produto 2 -->
                        <div class="produto-card" data-category="hardware">
                            <div class="produto-badge sale">-18%</div>
                            <div class="produto-image">
                                <img src="https://images.unsplash.com/photo-1591488320449-011701bb6704?w=400" alt="Placa de Vídeo">
                                <div class="produto-overlay">
                                    <button class="btn-quick-view">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="produto-info">
                                <h3 class="produto-title">Placa de Vídeo ASRock RX 6600 Challenger White AMD Radeon</h3>
                                <p class="produto-description">8GB, GDDR6, DirectX 12 Ultimate</p>
                                <div class="produto-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <span>(36)</span>
                                </div>
                                <div class="produto-footer">
                                    <div class="price-group">
                                        <span class="produto-price-old">R$ 1.999,99</span>
                                        <span class="produto-price">R$ 1.499,99</span>
                                        <span class="discount-badge">-18%</span>
                                    </div>
                                    <button class="btn-add-cart" onclick="addToCart('Placa de Vídeo ASRock RX 6600', 1499.99, 'https://images.unsplash.com/photo-1591488320449-011701bb6704?w=400')">
                                        <i class="fas fa-cart-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Produto 3 -->
                        <div class="produto-card" data-category="hardware">
                            <div class="produto-image">
                                <img src="https://images.unsplash.com/photo-1587202372634-32705e3bf49c?w=400" alt="GPU">
                                <div class="produto-overlay">
                                    <button class="btn-quick-view">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="produto-info">
                                <h3 class="produto-title">Placa de Vídeo MSI RTX 5070 12G Shadow 2x OC Nvidia GeForce</h3>
                                <p class="produto-description">12GB, GDDR7, OpenGL 4.6</p>
                                <div class="produto-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="far fa-star"></i>
                                    <span>(27)</span>
                                </div>
                                <div class="produto-footer">
                                    <span class="produto-price">R$ 3.789,99</span>
                                    <button class="btn-add-cart" onclick="addToCart('Placa de Vídeo MSI RTX 5070', 3789.99, 'https://images.unsplash.com/photo-1587202372634-32705e3bf49c?w=400')">
                                        <i class="fas fa-cart-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Produto 4 -->
                        <div class="produto-card" data-category="notebooks">
                            <div class="produto-badge">-10%</div>
                            <div class="produto-image">
                                <img src="https://images.unsplash.com/photo-1525547719571-a2d4ac8945e2?w=400" alt="Notebook Gamer">
                                <div class="produto-overlay">
                                    <button class="btn-quick-view">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="produto-info">
                                <h3 class="produto-title">Placa de Vídeo Gigabyte RTX 5060 EAGLE OC 8G NVIDIA GeForce</h3>
                                <p class="produto-description">8GB GDDR7, 128bits</p>
                                <div class="produto-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="far fa-star"></i>
                                    <span>(22)</span>
                                </div>
                                <div class="produto-footer">
                                    <div class="price-group">
                                        <span class="produto-price-old">R$ 2.600,00</span>
                                        <span class="produto-price">R$ 2.159,99</span>
                                        <span class="discount-badge">-10%</span>
                                    </div>
                                    <button class="btn-add-cart" onclick="addToCart('Placa de Vídeo Gigabyte RTX 5060', 2159.99, 'https://images.unsplash.com/photo-1525547719571-a2d4ac8945e2?w=400')">
                                        <i class="fas fa-cart-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Produto 5 -->
                        <div class="produto-card" data-category="smartphones">
                            <div class="produto-badge">Novo</div>
                            <div class="produto-image">
                                <img src="https://images.unsplash.com/photo-1592286927505-2c1c8a8f6493?w=400" alt="RTX 3060">
                                <div class="produto-overlay">
                                    <button class="btn-quick-view">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="produto-info">
                                <h3 class="produto-title">Placa de Vídeo RTX 3060 Ventus 2X 12G OC MSI GeForce</h3>
                                <p class="produto-description">12GB GDDR6, 15 Gbps</p>
                                <div class="produto-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <span>(109)</span>
                                </div>
                                <div class="produto-footer">
                                    <span class="produto-price">R$ 1.869,99</span>
                                    <button class="btn-add-cart" onclick="addToCart('Placa de Vídeo RTX 3060', 1869.99, 'https://images.unsplash.com/photo-1592286927505-2c1c8a8f6493?w=400')">
                                        <i class="fas fa-cart-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Produto 6 -->
                        <div class="produto-card" data-category="hardware">
                            <div class="produto-image">
                                <img src="https://images.unsplash.com/photo-1555680206-5e0849c8105f?w=400" alt="Processador">
                                <div class="produto-overlay">
                                    <button class="btn-quick-view">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="produto-info">
                                <h3 class="produto-title">Processador AMD Ryzen 3 3200G, 3.6GHz, 4-Core</h3>
                                <p class="produto-description">6MB Cache, AM4</p>
                                <div class="produto-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star-half-alt"></i>
                                    <span>(494)</span>
                                </div>
                                <div class="produto-footer">
                                    <span class="produto-price">R$ 589,99</span>
                                    <button class="btn-add-cart" onclick="addToCart('Processador AMD Ryzen 3', 589.99, 'https://images.unsplash.com/photo-1555680206-5e0849c8105f?w=400')">
                                        <i class="fas fa-cart-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Produto 7 -->
                        <div class="produto-card" data-category="perifericos">
                            <div class="produto-image">
                                <img src="https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=400" alt="SSD">
                                <div class="produto-overlay">
                                    <button class="btn-quick-view">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="produto-info">
                                <h3 class="produto-title">SSD Kingston Fury Renegade, 2TB, M.2 NVMe</h3>
                                <p class="produto-description">Leitura 7300MB/s</p>
                                <div class="produto-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <span>(94)</span>
                                </div>
                                <div class="produto-footer">
                                    <span class="produto-price">R$ 899,99</span>
                                    <button class="btn-add-cart" onclick="addToCart('SSD Kingston Fury Renegade 2TB', 899.99, 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=400')">
                                        <i class="fas fa-cart-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Produto 8 -->
                        <div class="produto-card" data-category="perifericos">
                            <div class="produto-image">
                                <img src="https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=400" alt="Memória RAM">
                                <div class="produto-overlay">
                                    <button class="btn-quick-view">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="produto-info">
                                <h3 class="produto-title">Memória RAM Para Notebook 8GB DDR4</h3>
                                <p class="produto-description">2666MHz, Corsair Value</p>
                                <div class="produto-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="far fa-star"></i>
                                    <span>(63)</span>
                                </div>
                                <div class="produto-footer">
                                    <span class="produto-price">R$ 189,99</span>
                                    <button class="btn-add-cart" onclick="addToCart('Memória RAM 8GB DDR4', 189.99, 'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=400')">
                                        <i class="fas fa-cart-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Produto 9 -->
                        <div class="produto-card" data-category="computadores">
                            <div class="produto-image">
                                <img src="https://images.unsplash.com/photo-1593642532842-98d0fd5ebc1a?w=400" alt="Placa Mãe">
                                <div class="produto-overlay">
                                    <button class="btn-quick-view">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="produto-info">
                                <h3 class="produto-title">Placa-Mãe Gigabyte A520M K V2, AMD AM4</h3>
                                <p class="produto-description">mATX, DDR4, M.2</p>
                                <div class="produto-rating">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star-half-alt"></i>
                                    <span>(85)</span>
                                </div>
                                <div class="produto-footer">
                                    <span class="produto-price">R$ 449,99</span>
                                    <button class="btn-add-cart" onclick="addToCart('Placa-Mãe Gigabyte A520M', 449.99, 'https://images.unsplash.com/photo-1593642532842-98d0fd5ebc1a?w=400')">
                                        <i class="fas fa-cart-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Pagination -->
                    <div class="pagination">
                        <button class="page-btn" disabled>
                            <i class="fas fa-chevron-left"></i>
                        </button>
                        <button class="page-btn active">1</button>
                        <button class="page-btn">2</button>
                        <button class="page-btn">3</button>
                        <span>...</span>
                        <button class="page-btn">12</button>
                        <button class="page-btn">
                            <i class="fas fa-chevron-right"></i>
                        </button>
                    </div>
                </main>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-col">
                    <div class="logo">
                        <i class="fas fa-store"></i>
                        <span>TechStore</span>
                    </div>
                    <p>Sua loja de tecnologia de confiança</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                    </div>
                </div>
                <div class="footer-col">
                    <h3>Links Rápidos</h3>
                    <ul>
                        <li><a href="index.html">Home</a></li>
                        <li><a href="produtos.html">Produtos</a></li>
                        <li><a href="sobre.html">Sobre</a></li>
                        <li><a href="dashboard.html">Dashboard</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h3>Suporte</h3>
                    <ul>
                        <li><a href="#">FAQ</a></li>
                        <li><a href="#">Política de Privacidade</a></li>
                        <li><a href="#">Termos de Uso</a></li>
                        <li><a href="#">Contato</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h3>Newsletter</h3>
                    <p>Receba nossas ofertas exclusivas</p>
                    <form class="newsletter-form">
                        <input type="email" placeholder="Seu e-mail">
                        <button type="submit"><i class="fas fa-paper-plane"></i></button>
                    </form>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 TechStore. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>

    <!-- Cart Modal -->
    <div class="cart-modal" id="cartModal">
        <div class="cart-content">
            <div class="cart-header">
                <h2><i class="fas fa-shopping-cart"></i> Carrinho</h2>
                <button class="close-cart">&times;</button>
            </div>
            <div class="cart-items" id="cartItems">
                <p class="empty-cart">Seu carrinho está vazio</p>
            </div>
            <div class="cart-footer">
                <div class="cart-total">
                    <span>Total:</span>
                    <span id="cartTotal">R$ 0,00</span>
                </div>
                <button class="btn btn-primary" onclick="finalizarCompra()">
                    <i class="fas fa-check"></i> Finalizar Compra
                </button>
            </div>
        </div>
    </div>

    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="js/loja-data.js"></script>
    <script src="js/theme-switcher.js"></script>
    <script src="js/main.js"></script>
    <script src="js/produtos.js"></script>
</body>

</html>